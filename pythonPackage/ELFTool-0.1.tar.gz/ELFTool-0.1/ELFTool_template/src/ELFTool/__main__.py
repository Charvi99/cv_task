import sys
import ELFTool
if __name__ == '__main__':
    sys.exit(ELFTool.main(sys.argv))