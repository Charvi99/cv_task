# ELF File reader
ELF File reader is tool for analysis Executable and Linkable Format files. 
It provides information of each segment about 
- type
- offset in memory
- size in file
- size in memory

## Usage

## Instalation as python package

## Instalation as Windows executable
